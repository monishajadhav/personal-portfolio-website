Save your screenshots here as desktop.png and mobile.png after opening the website in a browser.
