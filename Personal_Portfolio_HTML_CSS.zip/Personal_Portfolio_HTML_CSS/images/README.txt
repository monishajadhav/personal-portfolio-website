Optional images folder. If you add a profile photo, save it here and include meaningful alt text in index.html.
