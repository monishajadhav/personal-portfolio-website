PERSONAL PORTFOLIO — PROJECT NOTES
====================================

Folder structure
----------------
Personal_Portfolio_HTML_CSS/
├── index.html
├── style.css
├── images/
│   └── README.txt
└── screenshots/
    └── README.txt

How to run
----------
1. Extract the ZIP file.
2. Open the folder in Visual Studio Code (or another editor).
3. Open index.html in Chrome or Edge. No server or installation is required.
4. Edit index.html to replace the sample name, biography, education, project descriptions,
   email address, and profile links with your own details.
5. Adjust the colours at the top of style.css if you want a different palette.

Screenshots
-----------
Open index.html in your browser and capture:
- A desktop screenshot at a desktop width.
- A mobile screenshot using browser Developer Tools device emulation.
Save them in this screenshots/ folder as desktop.png and mobile.png.

Important
---------
This project intentionally uses only HTML5 and CSS3, as requested by the project guide.
The contact links use sample details and must be updated before submission.
Project cards are sample content; replace them with your own work.
